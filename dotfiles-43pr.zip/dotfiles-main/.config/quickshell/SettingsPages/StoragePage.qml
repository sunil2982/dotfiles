import QtQuick
import QtQuick.Controls
import Quickshell.Io
import "../"

Item {
    id: page
    property var drives: []
    property var filesystems: []
    property var cleanupInfo: ({yay:0, pacman:0, pacman1:0, pacmanrm:0, journal:0, trash:0, flatpak:0, cliphist:0, thumbs:0})
    property var sdaUsageData: null
    property real marginLeft: 0
    property real marginRight: 10
    property real marginTop: 0
    property real marginBottom: 0
    property string pendingAction: ""
    property string pendingTitle: ""
    property string pendingMessage: ""
    property string pendingKey: ""

    // Result tracking for cleanup buttons
    property string runningKey: ""          // key of the cleanup currently running / being measured
    property real beforeValue: 0            // that key's size (or count) before the command ran
    property int lastExitCode: 0
    property var cleanupResults: ({})       // key -> { kind: "ok" | "none" | "fail", text: "..." }

    readonly property var cleanupDefaults: ({yay:0, pacman:0, pacman1:0, pacmanrm:0, journal:0, trash:0, flatpak:0, cliphist:0, thumbs:0})
    readonly property var sizeUnits: ({
        B:1, K:1024, KB:1024, KIB:1024,
        M:1048576, MB:1048576, MIB:1048576,
        G:1073741824, GB:1073741824, GIB:1073741824,
        T:1099511627776, TB:1099511627776, TIB:1099511627776
    })

    function formatBytes(b) {
        if (!isFinite(b) || b < 0) return "0 B"
        var u = ["B", "KB", "MB", "GB", "TB"]
        var i = 0
        var v = b
        while (v >= 1024 && i < u.length - 1) { v /= 1024; ++i }
        return (i ? v.toFixed(1) : Math.round(v)) + " " + u[i]
    }

    function formatCount(n) {
        var v = Math.round(n) || 0
        return v + (v === 1 ? " ITEM" : " ITEMS")
    }

    function parseSize(v) {
        if (!v) return 0
        var m = v.trim().match(/^([0-9.]+)\s*([A-Za-z]*)$/)
        if (!m) return 0
        var n = parseFloat(m[1])
        if (isNaN(n)) return 0
        return n * (m[2] ? (sizeUnits[m[2].toUpperCase()] || 1) : 1)
    }

    function usageColor(p) { return p >= 90 ? Theme.danger : p >= 75 ? Theme.accent2 : Theme.accent }
    function usageWidth(p) { return Math.min(1, Math.max(0, p / 100)) }
    function ignoredMount(m) { return ["/proc", "/sys", "/run", "/dev"].some(function(x) { return m.indexOf(x) === 0 }) }
    function ignoredFilesystem(f) { return ["tmpfs", "devtmpfs", "overlay"].some(function(x) { return f.indexOf(x) === 0 }) }

    function parseDfLine(line) {
        var f = line.trim().split(/\s+/)
        if (f.length < 6) return null
        var d = {
            filesystem: f[0], total: parseInt(f[1]), used: parseInt(f[2]),
            available: parseInt(f[3]), percent: parseInt(f[4]), mount: f.slice(5).join(" ")
        }
        if ([d.total, d.used, d.available, d.percent].some(isNaN) || ignoredMount(d.mount) || ignoredFilesystem(d.filesystem)) return null
        return d
    }

    function parseDriveData(data) {
        var disks = []
        try {
            var obj = JSON.parse(data)
            if (!obj.blockdevices) return disks
            for (var i = 0; i < obj.blockdevices.length; ++i) {
                var d = obj.blockdevices[i]
                if (d.type === "disk" && d.name === "sda")
                    disks.push({ name: d.name || "", model: d.model || "", size: parseInt(d.size) || 0, type: d.type || "", tran: d.tran || "" })
            }
        } catch (e) { console.log("lsblk JSON error:", e) }
        return disks
    }

    function findSdaUsage() {
        var used = 0
        for (var i = 0; i < filesystems.length; ++i) {
            var fs = filesystems[i]
            if (fs.filesystem.indexOf("/dev/sda") === 0) used += fs.used
        }
        return used > 0 ? {used: used} : null
    }

    // k is the cleanup key, used to measure what the command changed
    function runCommand(c, k) {
        runningKey = k || ""
        beforeValue = k ? (cleanupInfo[k] || 0) : 0
        lastExitCode = 0
        commandProcess.command = ["sh", "-c", c]
        commandProcess.running = true
    }

    function refreshAll() { pDrives.running = pStorage.running = pCleanup.running = true }

    function confirmAction(t, m, c, k) {
        if (commandProcess.running) return
        pendingTitle = t; pendingMessage = m; pendingAction = c; pendingKey = k || ""
        confirmPopup.visible = true
    }

    function setResult(key, kind, text) {
        var next = {}
        for (var k in cleanupResults) next[k] = cleanupResults[k]
        next[key] = { kind: kind, text: text }
        cleanupResults = next
    }

    // Called once the post-command cleanup measurement has finished
    function finishCleanup() {
        var key = runningKey
        if (!key) return
        var before = beforeValue
        var after = cleanupInfo[key] || 0
        var code = lastExitCode

        if (code !== 0) {
            if (code === 126 || code === 127)
                setResult(key, "fail", "CANCELLED OR NOT AUTHORIZED")
            else
                setResult(key, "fail", "FAILED (EXIT " + code + ")")
        } else if (before <= 0) {
            setResult(key, "none", "ALREADY CLEAN - NOTHING TO REMOVE")
        } else if (before - after > 0) {
            setResult(key, "ok", key === "cliphist"
                ? "REMOVED " + formatCount(before - after)
                : "FREED " + formatBytes(before - after))
        } else {
            setResult(key, "none", "NO CHANGE")
        }
        runningKey = ""
    }

    Process {
        id: pDrives
        command: ["sh", "-c", "lsblk -J -b -d -o NAME,MODEL,SIZE,TYPE,TRAN 2>/dev/null"]
        stdout: StdioCollector { onStreamFinished: page.drives = page.parseDriveData(text) }
        stderr: StdioCollector {}
    }

    Process {
        id: pStorage
        command: ["sh", "-c", "df -P -B1 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                var fs = []
                var lines = text.trim().split("\n")
                for (var i = 0; i < lines.length; ++i) {
                    var item = page.parseDfLine(lines[i])
                    if (item) fs.push(item)
                }
                page.filesystems = fs
                page.sdaUsageData = page.findSdaUsage()
            }
        }
        stderr: StdioCollector {}
    }

    // PACMAN / PACMAN1 / PACMANRM report what each button WOULD free (paccache dry run),
    // not the total cache size, so "0 B" means the button has nothing to do.
    Process {
        id: pCleanup
        command: [
            "sh", "-c",
            "p() { printf '%s %s\\n' \"$1\" \"${2:-0}\"; }; " +
            "pc() { paccache -d \"$@\" 2>/dev/null | grep -oE 'disk space saved: [0-9.]+ ?[KMGT]i?B' | grep -oE '[0-9.]+ ?[KMGT]i?B' | tail -1 | tr -d ' '; }; " +
            "p YAY \"$(du -sb \"$HOME/.cache/yay\" 2>/dev/null | awk '{print $1}')\"; " +
            "p PACMAN \"$(pc -k3)\"; " +
            "p PACMAN1 \"$(pc -k1)\"; " +
            "p PACMANRM \"$(pc -u -k0)\"; " +
            "p JOURNAL \"$(journalctl --disk-usage 2>/dev/null | grep -oE '[0-9.]+ ?[BKMGT]' | tail -1 | tr -d ' ')\"; " +
            "p TRASH \"$(du -sb \"$HOME/.local/share/Trash\" 2>/dev/null | awk '{print $1}')\"; " +
            "p FLATPAK \"$(flatpak uninstall --unused --assumeno 2>/dev/null | grep -oE '[0-9.]+ ?(kB|MB|GB|TB)' | tail -1 | tr -d ' ')\"; " +
            "p CLIPHIST \"$(cliphist list 2>/dev/null | wc -l)\"; " +
            "p THUMBS \"$(du -sb \"$HOME/.cache/quickshell/thumbs\" 2>/dev/null | awk '{print $1}')\""
        ]
        stdout: StdioCollector {
            onStreamFinished: {
                var info = {yay: 0, pacman: 0, pacman1: 0, pacmanrm: 0, journal: 0, trash: 0, flatpak: 0, cliphist: 0, thumbs: 0}
                var lines = text.trim().split("\n")
                for (var i = 0; i < lines.length; ++i) {
                    var p = lines[i].trim().split(/\s+/)
                    var k = p[0] ? p[0].toLowerCase() : ""
                    if (p.length > 1 && info[k] !== undefined) info[k] = page.parseSize(p.slice(1).join(" "))
                }
                page.cleanupInfo = info
                page.finishCleanup()
            }
        }
        stderr: StdioCollector {}
    }

    Process {
        id: commandProcess
        stdout: StdioCollector {}
        stderr: StdioCollector {
            onStreamFinished: if (text.trim()) console.warn("[storage] cleanup stderr:", text.trim())
        }
        onExited: (exitCode, exitStatus) => {
            page.lastExitCode = exitCode
            if (exitCode !== 0) console.warn("[storage] cleanup exited with code", exitCode)
            page.refreshAll()
        }
    }

    Rectangle {
        id: confirmPopup
        visible: false; anchors.centerIn: parent; z: 100
        width: Math.min(parent.width - 30, 420);
        height: 220; radius: Theme.radius
        color: Theme.bg; border.width: 1; border.color: Theme.accent

        Column {
            anchors.fill: parent; anchors.margins: 18; spacing: 12
            Text {
                text: page.pendingTitle; color: Theme.text
                font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeTitle; font.bold: true
            }
            Text {
                width: parent.width; text: page.pendingMessage; color: Theme.textDim
                font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeGroup; wrapMode: Text.WordWrap
            }
            Item { width: 1; height: 1 }
            Row {
                width: parent.width; spacing: 10
                ToolButton {
                    width: (parent.width - 8) / 2; label: "CANCEL"
                    onClicked: confirmPopup.visible = false
                }
                ToolButton {
                    width: (parent.width - 8) / 2; label: "CONFIRM"; accent: true
                    onClicked: { confirmPopup.visible = false; page.runCommand(page.pendingAction, page.pendingKey) }
                }
            }
        }
    }

    // Cheap stats (df / lsblk) every 10s
    Timer {
        interval: 10000; running: true; repeat: true
        onTriggered: { pDrives.running = true; pStorage.running = true }
    }
    // Expensive stats (du, paccache dry runs, flatpak, cliphist) every 60s, never while a cleanup is running
    Timer {
        interval: 60000; running: true; repeat: true
        onTriggered: if (!commandProcess.running && page.runningKey === "") pCleanup.running = true
    }
    Component.onCompleted: page.refreshAll()

    Column {
        anchors.fill: parent
        anchors.leftMargin: page.marginLeft; anchors.rightMargin: page.marginRight
        anchors.topMargin: page.marginTop; anchors.bottomMargin: page.marginBottom
        spacing: 14

        Text {
            text: "STORAGE"; color: Theme.text
            font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeTitle; font.letterSpacing: 3
        }

        Rectangle { width: parent.width; height: 1; color: Theme.border }

        Item {
            width: parent.width; height: parent.height - y

            Flickable {
                id: flick
                anchors.fill: parent; clip: true
                contentWidth: width; contentHeight: list.height
                boundsBehavior: Flickable.StopAtBounds

                ScrollBar.vertical: ScrollBar {
                    id: scrollBar
                    background: Rectangle {
                        color: Theme.alpha(Theme.border, 0)
                        radius: width / 2
                    }
                    contentItem: Rectangle {
                        color: Theme.accent
                        radius: width / 2
                    }
                }

                Column {
                    id: list
                    width: parent.width; spacing: 10

                    Text {
                        text: "DRIVES"; color: Theme.text
                        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeSection; font.bold: true; font.letterSpacing: 2
                    }

                    Repeater {
                        model: page.drives
                        delegate: Item {
                            required property var modelData
                            property bool hasUsage: page.sdaUsageData !== null && modelData.size > 0
                            property real usedPct: hasUsage ? (page.sdaUsageData.used / modelData.size) * 100 : 0
                            width: list.width; height: 64

                            Column {
                                anchors.fill: parent; spacing: 9

                                Row {
                                    width: parent.width; height: 17
                                    Text {
                                        width: parent.width - 70; text: modelData.model || modelData.name || "SSD/HDD"
                                        color: Theme.text; elide: Text.ElideRight; verticalAlignment: Text.AlignVCenter
                                        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeGroup; font.bold: true
                                    }
                                    Text {
                                        width: 70; text: hasUsage ? Math.round(usedPct) + "%" : "--%"
                                        color: hasUsage ? page.usageColor(usedPct) : Theme.textDim
                                        horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter
                                        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeGroup; font.bold: true
                                    }
                                }

                                Rectangle {
                                    width: parent.width; height: 4; radius: 2
                                    color: Theme.alpha(Theme.textDim, .15)
                                    Rectangle {
                                        width: hasUsage ? parent.width * page.usageWidth(usedPct) : 0
                                        height: parent.height; radius: 2
                                        color: hasUsage ? page.usageColor(usedPct) : Theme.accent
                                        Behavior on width { NumberAnimation { duration: Theme.animMed } }
                                    }
                                }

                                Row {
                                    width: parent.width; height: 13; spacing: 14
                                    Text {
                                        text: page.sdaUsageData ? page.formatBytes(page.sdaUsageData.used) + " USED" : "-- USED"
                                        color: Theme.textDim; font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody
                                    }
                                    Text {
                                        text: page.sdaUsageData && modelData.size > page.sdaUsageData.used
                                            ? page.formatBytes(modelData.size - page.sdaUsageData.used) + " FREE" : "-- FREE"
                                        color: Theme.textDim; font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody
                                    }
                                    Text {
                                        text: page.formatBytes(modelData.size) + " TOTAL"
                                        color: Theme.textDim; font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody
                                    }
                                }
                            }
                        }
                    }

                    Text {
                        text: "FILESYSTEM"; color: Theme.text; topPadding: 4
                        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeSection; font.bold: true; font.letterSpacing: 2
                    }

                    Repeater {
                        model: page.filesystems
                        delegate: Item {
                            required property var modelData
                            width: list.width; height: 64

                            Column {
                                anchors.fill: parent; spacing: 9

                                Row {
                                    width: parent.width; height: 17
                                    Text {
                                        width: parent.width - 55; text: modelData.mount
                                        color: Theme.text; elide: Text.ElideRight; verticalAlignment: Text.AlignVCenter
                                        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeGroup; font.bold: true
                                    }
                                    Text {
                                        width: 55; text: modelData.percent + "%"; color: page.usageColor(modelData.percent)
                                        horizontalAlignment: Text.AlignRight; verticalAlignment: Text.AlignVCenter
                                        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeGroup; font.bold: true
                                    }
                                }

                                Rectangle {
                                    width: parent.width; height: 4; radius: 2
                                    color: Theme.alpha(Theme.textDim, .15)
                                    Rectangle {
                                        width: parent.width * page.usageWidth(modelData.percent)
                                        height: parent.height; radius: 2; color: page.usageColor(modelData.percent)
                                        Behavior on width { NumberAnimation { duration: Theme.animMed } }
                                    }
                                }

                                Row {
                                    width: parent.width; height: 13; spacing: 14
                                    Text {
                                        text: page.formatBytes(modelData.used) + " USED"
                                        color: Theme.textDim; font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody
                                    }
                                    Text {
                                        text: page.formatBytes(modelData.available) + " FREE"
                                        color: Theme.textDim; font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody
                                    }
                                    Text {
                                        text: page.formatBytes(modelData.total) + " TOTAL"
                                        color: Theme.textDim; font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody
                                    }
                                }
                            }
                        }
                    }

                    Text {
                        text: "CLEANUP"; color: Theme.text; topPadding: 4
                        font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeSection; font.bold: true; font.letterSpacing: 2
                    }

                    Repeater {
                        model: [
                            {
                                key: "trash", label: "TRASH", action: "EMPTY", title: "EMPTY TRASH?",
                                message: "This permanently deletes everything in ~/.local/share/Trash.\n\nCommand: rm -rf -- \"$HOME/.local/share/Trash/files/\"* \"$HOME/.local/share/Trash/info/\"*",
                                command: "rm -rf -- \"$HOME/.local/share/Trash/files/\"* \"$HOME/.local/share/Trash/info/\"*"
                            },
                            {
                                key: "cliphist", label: "CLIPHIST", action: "WIPE", title: "WIPE CLIPBOARD HISTORY?",
                                message: "This keeps the 20 most recent clipboard entries and permanently deletes the rest.\n\nCommand: cliphist list | tail -n +21 | cliphist delete",
                                command: "cliphist list | tail -n +21 | cliphist delete"
                            },
                            {
                                key: "thumbs", label: "WALLPAPER PICKER", action: "CLEAR", title: "CLEAR THUMBNAIL CACHE?",
                                message: "This permanently deletes everything in ~/.cache/quickshell/thumbs.\n\nCommand: rm -rf -- \"$HOME/.cache/quickshell/thumbs/\"*",
                                command: "rm -rf -- \"$HOME/.cache/quickshell/thumbs/\"*"
                            },
                            {
                                key: "yay", label: "YAY CACHE", action: "CLEAN", title: "CLEAR YAY CACHE?",
                                message: "This permanently deletes cached AUR build files and downloaded sources.\n\nCommand: rm -rf -- \"$HOME/.cache/yay/\"*",
                                command: "rm -rf -- \"$HOME/.cache/yay/\"*"
                            },
                            {
                                key: "pacman", label: "PACMAN CACHE", action: "KEEP 3", title: "CLEAN PACMAN CACHE?",
                                message: "This removes old cached package versions while keeping the 3 most recent versions of each package.\n\nCommand: pkexec paccache -r",
                                command: "pkexec paccache -r"
                            },
                            {
                                key: "pacman1", label: "PACMAN CACHE", action: "KEEP 1", title: "KEEP ONLY 1 VERSION?",
                                message: "This removes all cached versions of installed packages except the most recent one. You will not be able to downgrade a package from the cache.\n\nCommand: pkexec paccache -rk1",
                                command: "pkexec paccache -rk1"
                            },
                            {
                                key: "pacmanrm", label: "PACMAN UNINSTALLED", action: "REMOVE", title: "REMOVE UNINSTALLED PACKAGES?",
                                message: "This removes every cached version of packages that are no longer installed.\n\nCommand: pkexec paccache -ruk0",
                                command: "pkexec paccache -ruk0"
                            },
                            {
                                key: "journal", label: "JOURNAL", action: "7 DAYS", title: "VACUUM JOURNAL?",
                                message: "This permanently deletes system journal logs older than 7 days.\n\nCommand: pkexec journalctl --vacuum-time=7d",
                                command: "pkexec journalctl --vacuum-time=7d"
                            },
                            {
                                key: "flatpak", label: "FLATPAK UNUSED", action: "CLEAN", title: "REMOVE UNUSED FLATPAKS?",
                                message: "This removes unused Flatpak runtimes and packages.\n\nCommand: flatpak uninstall --unused -y",
                                command: "flatpak uninstall --unused -y"
                            }
                        ]

                        delegate: CleanupButton {
                            required property var modelData
                            readonly property bool busy: page.runningKey === modelData.key
                            readonly property var res: page.cleanupResults[modelData.key]

                            width: list.width
                            label: modelData.label
                            value: modelData.key === "cliphist" ? page.formatCount(page.cleanupInfo.cliphist) : page.formatBytes(page.cleanupInfo[modelData.key])
                            actionText: modelData.action
                            resultText: busy ? (commandProcess.running ? "WORKING..." : "MEASURING...") : (res ? res.text : "")
                            resultKind: busy ? "busy" : (res ? res.kind : "")
                            onClicked: page.confirmAction(
                                modelData.title,
                                modelData.message === "CACHE_PLACEHOLDER"
                                    ? page.formatBytes(page.cleanupInfo.yay) + " currently in ~/.cache/yay"
                                    : modelData.message,
                                modelData.command,
                                modelData.key
                            )
                        }
                    }
                }
            }
        }
    }

    component ToolButton: Rectangle {
        property string label: ""
        property bool accent: false
        signal clicked()
        height: 38; radius: Theme.radius; color: "#00000000"
        border.width: 1; border.color: Theme.border

        Text {
            anchors.centerIn: parent; text: parent.label
            color: parent.accent ? Theme.accent : Theme.textDim
            font.family: Theme.fontFamily; font.pixelSize: Theme.textSizeBody; font.bold: true; font.letterSpacing: .5
        }

        MouseArea {
            anchors.fill: parent; hoverEnabled: true
            onEntered: { parent.color = Theme.alpha(Theme.accent, 0.08); parent.border.color = Theme.accent }
            onExited: { parent.color = "#00000000"; parent.border.color = Theme.border }
            onClicked: parent.clicked()
        }
    }

    component CleanupButton: Rectangle {
        id: cleanupRoot
        required property string label
        required property string value
        required property string actionText
        property string resultText: ""
        property string resultKind: ""      // "ok" | "none" | "fail" | "busy" | ""
        signal clicked()

        readonly property bool hasResult: resultText !== ""

        width: parent.width
        height: hasResult ? 58 : 42
        radius: Theme.radius
        color: "#00000000"
        border.width: 1
        border.color: Theme.border

        Text {
            anchors.left: parent.left
            anchors.leftMargin: 14
            anchors.verticalCenter: parent.verticalCenter
            anchors.verticalCenterOffset: cleanupRoot.hasResult ? -9 : 0
            text: cleanupRoot.label
            color: Theme.textDim
            font.family: Theme.fontFamily
            font.pixelSize: Theme.textSizeGroup
            font.bold: true
            font.letterSpacing: 2
        }

        Row {
            anchors.right: parent.right
            anchors.rightMargin: 14
            anchors.verticalCenter: parent.verticalCenter
            anchors.verticalCenterOffset: cleanupRoot.hasResult ? -9 : 0
            spacing: 8

            Text {
                text: cleanupRoot.value
                color: Theme.textDim
                font.family: Theme.fontFamily
                font.pixelSize: Theme.textSizeGroup
                anchors.verticalCenter: parent.verticalCenter
            }

            Text {
                text: cleanupRoot.actionText
                color: Theme.textDim
                font.family: Theme.fontFamily
                font.pixelSize: Theme.textSizeGroup
                font.bold: true
                font.letterSpacing: 1
                anchors.verticalCenter: parent.verticalCenter
            }
        }

        Text {
            visible: cleanupRoot.hasResult
            anchors.left: parent.left
            anchors.leftMargin: 14
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 9
            text: cleanupRoot.resultText
            color: cleanupRoot.resultKind === "ok" ? Theme.accent
                 : cleanupRoot.resultKind === "fail" ? Theme.danger
                 : Theme.textDim
            font.family: Theme.fontFamily
            font.pixelSize: Theme.textSizeBody
            font.bold: true
            font.letterSpacing: 1
        }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true

            onEntered: {
                parent.color = Theme.alpha(Theme.accent, 0.08)
                parent.border.color = Theme.accent
            }

            onExited: {
                parent.color = "#00000000"
                parent.border.color = Theme.border
            }

            onClicked: cleanupRoot.clicked()
        }
    }
}